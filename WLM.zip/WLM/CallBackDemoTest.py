######################################################################################################
# @file CallBackDemo.py
# @copyright HighFinesse GmbH.
# @author Lovas Szilard <lovas@highfinesse.de>
# @date 2018.09.16
# @version 0.1
#
# Homepage: http://www.highfinesse.com/
#
# @brief Python language example for demonstrating usage of wlmData.dll CallBack mechanism.
# Tested with Python 3.7.
# 64-bit Python requires 64-bit wlmData.dll (in System32 folder) and
# 32-bit Python requires 32-bit wlmData.dll (in SysWOW64 folder on Win64 or System32 folder on Win32).
# For more information see the ctypes module documentation:
# https://docs.python.org/3/library/ctypes.html
# and/or WLM manual.pdf
#
# Changelog:
# ----------
# 2018.09.16
# v0.1 - Initial release
#

# wlmData.dll related imports
import wlmData
import wlmConst

# others
import sys
import time

import socket

# SocketBegin------------------------------------------------------------
# 1、创建socket通信对象
clientSocket = socket.socket()

# 2、使用正确的ip和端口去链接服务器
clientSocket.connect(("192.168.0.76",8888))

# 3、客户端与服务器端进行通信
# 给socket服务器发送信息

# 接收服务器的响应(服务器回复的消息)
# recvData = clientSocket.recv(1024).decode('GB2312')
# print('客户端收到服务器回复的消息:%s' % (recvData))

# 4、关闭socket对象
# clientSocket.close()

# Socket----------------------------------------------------------------

# Set the DLL_PATH variable according to your environment here:
DLL_PATH = "C:\\WINDOWS\system32\wlmData.dll"

# Set the Data acquisition time (sec) here:
DATA_ACQUISITION_TIME = 0.2

# Set the CallBack Thread priority here:
CALLBACK_THREAD_PRIORITY = 2

# Create callback function type using stdcall (WINFUNCTYPE) calling convention.
# The original function signature is void function(long, unsigned long, double)
# For more information see ctypes python library documentation.
CallBackFuncType = wlmData.ctypes.WINFUNCTYPE(None, wlmData.ctypes.c_long, wlmData.ctypes.c_ulong, wlmData.ctypes.c_double)

# 设置传输给主机的数据
# Setting the data for the TCP/IP socket
def TCPIP(WaveNum, Meter):
    Data=str(WaveNum)+" "+str(Meter)
    clientSocket.send(Data.encode('GB2312'))
    recvData = clientSocket.recv(1024).decode('GB2312')


# Function definition for CallBack function
def MyCallBack(Mode, IntVal, DblVal):
    if Mode == wlmConst.cmiWavelength1:
        TCPIP(1,DblVal)
    elif Mode == wlmConst.cmiWavelength2:
        TCPIP(2,DblVal)
    elif Mode == wlmConst.cmiWavelength3:
        TCPIP(3,DblVal)
    elif Mode == wlmConst.cmiWavelength4:
        print("Ch4 wawelength (vac): %f nm" % DblVal);
        TCPIP(4,DblVal)
    elif Mode == wlmConst.cmiWavelength5:
        TCPIP(5,DblVal)
    elif Mode == wlmConst.cmiWavelength6:
        TCPIP(6,DblVal)
    elif Mode == wlmConst.cmiWavelength7:
        
        TCPIP(7,DblVal)
    elif Mode == wlmConst.cmiWavelength8:
        TCPIP(8,DblVal)
# Main program execution starts here
# Load DLL from DLL_PATH
try:
    wlmData.LoadDLL(DLL_PATH)
except:
    sys.exit("Error: Couldn't find DLL on path %s.\nPlease check the DLL_PATH variable!" % DLL_PATH)

# Checks the number of WLM server instance(s)
if wlmData.dll.GetWLMCount(0) == 0:
    print("There is no running wlmServer instance(s).")
else:
    # Creates function pointer to the CallBackFuncType type-casted function
    pCallBackFunction = CallBackFuncType(MyCallBack)

    print("Data acquisition by Callback function for %s seconds." % DATA_ACQUISITION_TIME)

    while True:
        # Installs CallBack function
        # The tricky part: Casting pCallBackFunction to long pointer (long *)
        wlmData.dll.Instantiate(wlmConst.cInstNotification, wlmConst.cNotifyInstallCallback, wlmData.ctypes.cast(pCallBackFunction, wlmData.ctypes.POINTER(wlmData.ctypes.c_long)), CALLBACK_THREAD_PRIORITY)

        # Gives a little time for data acquisition

        time.sleep(DATA_ACQUISITION_TIME)

    # Removes CallBack function
    wlmData.dll.Instantiate(wlmConst.cInstNotification, wlmConst.cNotifyRemoveCallback, None, 0)

    print("CallBack function was removed.")

clientSocket.close()
